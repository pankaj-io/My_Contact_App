
const asyncHandler = require("express-async-handler");
const Contact =  require("../models/contactModel");

//@describe get all contacts
//@route GEt api/contacts
//@access private
const getContacts = asyncHandler(async(req,resp)=>{
    const contacts = await Contact.find({user_id : req.user.id});
    resp.status(200).json(contacts);
});

//@describe create new contacts
//@route POST api/contacts
//@access private
const createContact = asyncHandler(async(req,resp)=>{
    console.log("This is my contact detail(request body is this) " ,req.body)
    const {name, email,phone} = req.body;
    if(!name || !email || !phone){
        resp.status(400);
        throw new Error("All fields are necessary...!");
    }
    const contact = await Contact.create({
        name,
        email,
        phone,
        user_id:req.user.id,
    }); 
    resp.status(201).json(contact);
});

//@describe Get contacts
//@route GET api/contacts/:id
//@access private
const getContact = asyncHandler(async(req,resp)=>{
    const contact = await Contact.findById(req.params.id);
    if(!contact){
        resp.status(404);
        throw new Error("Contact not found!");
    }
    resp.status(200).json(contact);
});

//@describe update contact
//@route PUT api/contacts/:id
//@access private
const updateContact = asyncHandler(async(req,resp)=>{
    const contact = await Contact.findById(req.params.id);
    if(!contact){
        resp.status(404);
        throw new Error("Contact not found!");
    }
    if(contact.user_id.toString() !== req.user_id){
        resp.status(403);
        throw new Error("User don't have permission to update other user contacts");
    }

    const updatedContact = await Contact.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
            new : true
        }
    );
    resp.status(200).json(updatedContact);
    // resp.status(200).json({message : `Update contact for ${req.params.id}` });
});

//@describe delete contact
//@route DELETE api/contacts/:id
//@access private 
const deleteContact = asyncHandler(async(req,resp)=>{

    const contact = await Contact.findById(req.params.id);
    if(!contact){
        resp.status(404);
        throw new Error("Contact not found!");
    }
    if(contact.user_id.toString() !== req.user_id){
        resp.status(403);
        throw new Error("User don't have permission to delete other user contacts");
    }  

    await Contact.deleteOne({ _id: req.params.id }); // Delete the contact found by its ID
    resp.status(200).json(contact);
    // resp.status(200).json({message :` Delete contact for ${req.params.id}`});
});


module.exports = {
    getContacts ,
    createContact,
    getContact,
    updateContact,
    deleteContact
    }